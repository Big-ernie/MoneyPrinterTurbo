#!/bin/bash
# macOS convenient starter, never places trades.
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! command -v git >/dev/null 2>&1; then
  echo 'Git is required. Install Apple Command Line Tools with: xcode-select --install'
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Python 3 is required (version 3.8 or newer).'
  exit 1
fi
python3 convert_day_trader.py --mode global
printf '\nInstalled. Restart Codex to discover all eleven skills.\n'

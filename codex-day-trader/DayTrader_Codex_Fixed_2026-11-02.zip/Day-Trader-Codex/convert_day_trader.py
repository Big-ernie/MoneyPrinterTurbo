#!/usr/bin/env python3
"""Convert Jake Schincariol's day-trader-skill for Codex (MIT licensed upstream).

No third-party Python packages. Clones source, rewrites instructions, preserves
original Python tools, and produces skills or a portable Codex plugin.
Does not run trading scripts, access brokerage credentials, or place orders.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
from typing import Optional
import re
import shutil
import subprocess
import sys
import tempfile

UPSTREAM = 'https://github.com/Jakeschincariol/day-trader-skill.git'
PINNED_SHA = '3d0f4ef6986f4984b7c6bd46f7ff4f87744c3abd'
NAMES = ['alerts', 'analyst', 'broker', 'budget', 'entry', 'exit', 'news', 'pelosi', 'risk', 'scanner', 'timemachine']
DESCRIPTIONS = {
 'alerts': 'Manage US equity price, stop-loss, take-profit, market-open and flat-by-close alerts using public quote data. Use for price alert creation, checking alerts, and observing a paper trade. Alerts do not place orders or run continuously unless separately scheduled.',
 'analyst': 'Analyze US public-company earnings and SEC EDGAR financial filings. Use when reviewing quarterly revenue, margins, EPS, earnings releases, or fundamental changes for a stock.',
 'broker': 'Display and audit trade tickets, record explicit approvals, and optionally route individually approved PAPER orders through a separately configured broker MCP tool. Use for paper trading, order tickets, fills, or closing a position. No live orders or automatic brokerage actions.',
 'budget': 'Size a US stock trade using budget, per-trade maximum loss, stop distance, buying power, position limits, and cash buffer. Use after defining entry, stop and target to propose an order without placing it.',
 'entry': 'Check intraday US stock price bars for entry conditions such as opening-range breakout. Use to monitor whether a setup has triggered on completed candles; not a price prediction.',
 'exit': 'Make a stop-loss and profit-target plan for a US stock setup, including risk/reward and market-close exit time. Use after entry confirmation and before paper position sizing.',
 'news': 'Monitor watchlist-related US stock headlines and SEC 8-K filings. Use to review fresh catalysts, company news and market-moving filings before a trade.',
 'pelosi': 'Read and summarize publicly disclosed congressional stock transactions and House Clerk Periodic Transaction Reports. Use when researching US Congress trading disclosures, not real-time insider trades.',
 'risk': 'Validate proposed US stock orders against stop-loss, daily-loss, max-position, market-hours, cash, and duplicate-order rules. Use before presenting any paper trading order for user confirmation.',
 'scanner': 'Scan US equity charts using public market data for technical setups such as opening-range breakouts, bull flags and oversold bounces. Use for market scans and watchlist building, not automatic buy recommendations.',
 'timemachine': 'Backtest a defined intraday US stock setup against previous sessions and simulate scenario outcomes using historical price bars. Use to evaluate trade plans before risking money; simulated odds are not forecasts.',
}

SAFETY = '''## Codex compatibility and trading safeguards

- These are analysis tools, not financial advice or a promise of returns. Source feeds can be stale or unavailable, and paper fills do not establish real execution performance.
- Default to simulation and paper trading only. Do not submit live orders, switch an account to live, or remove risk limits. Do not store or reveal API keys in chat or tracked files.
- Scripts produce or read local `trader/` project files. Run from the user's chosen project working directory, not from the skill directory.
- No order may be sent unless `trader-risk` has passed that *exact* order for today, the user expressly agrees to *that one* ticket during this conversation, and a configured broker integration exposes and obtains separate per-call approval. If the tool or per-call approval is missing, stop at the ticket.
- Do not place, cancel, change, or close orders from a background or scheduled process.
- No options, margin, short selling, leverage, or crypto orders.
'''

BROKER_BODY = '''# trader-broker: Codex paper-order adapter

Use this skill to show and log paper-trading order tickets. The original author's `ticket.py` is kept unchanged. It manages local JSON state; **it does not send brokerage requests**.

## Skill tool location

`CODEX_SKILL_DIR` is not a built-in variable. Codex should resolve the directory containing this `SKILL.md` and set `CODEX_SKILL_DIR` to that absolute path before running commands. For the standard personal install, `export CODEX_SKILL_DIR="${CODEX_HOME:-$HOME/.codex}/skills/trader-broker"`. Keep the command's working directory at the user's trading project root.

```bash
python3 "$CODEX_SKILL_DIR/ticket.py" show
python3 "$CODEX_SKILL_DIR/ticket.py" approve --index 1 --reply "yes"
python3 "$CODEX_SKILL_DIR/ticket.py" log
# Only after an actual broker response, record it:
python3 "$CODEX_SKILL_DIR/ticket.py" result --index 1 --status placed --broker-id BROKER_ID
```

## Paper trading order workflow

1. Verify `trader/config.json` exists, `"paper": true`, and the target brokerage connector is configured for a **paper account**. Do not assume Alpaca or Interactive Brokers tools are available merely because this skill is installed.
2. Run `$trader-risk` (the `check.py` script) on the exact `trader/orders.json` ticket and verify PASS for the same order fingerprint on the current New York market date. A PASS is a rules check, not authorization.
3. Run `ticket.py show`. Present the complete exact paper order, its symbol, side, size, stop, target, account mode and maximum loss assuming the stop fills at its price. Do not send a broker instruction yet.
4. Ask the user whether to submit **this exact paper order**, one order at a time. Only a fresh, unambiguous yes from the user in this conversation counts. For yes, run `ticket.py approve --index N --reply "yes"` and confirm that the tool reports the approval was recorded.
5. Before attempting any state-changing broker MCP tool, verify that Codex is configured to request an additional **per-call user approval** and that the integration points to a paper account. If either condition is unverified, stop at the ticket and explain that it was not submitted.
6. Request the configured paper-order tool with the unchanged, risk-checked ticket parameters. The tool's approval mechanism must block actual submission until the user approves that exact call. Only record a placed order after the broker returns a successful response. Never fabricate results. Log approved, denied, failed and filled responses using `ticket.py result` or `ticket.py fill`. A failed order requires a fresh risk check and new approvals before retrying.
7. Closing a paper position is also a state-changing action. Confirm actual holdings from the broker, build a flatten ticket, run the risk check and obtain the same two approvals. Be mindful of open bracket exits and broker-specific cancellation requirements.

There is **no built-in Codex Alpaca connection** in this pack. Configure an MCP broker integration separately, with credentials held in environment variables or the operating system's secret store, never placed in this chat or a repository. Configure order placement, cancellations and modifications to require human approval on every call. In the absence of an integration, this skill provides ticket preparation and local record-keeping only.

Read `references/UPSTREAM_BROKER.md` for original detailed ticket examples. Its Claude-specific connector setup steps are historical and **not instructions for Codex**.

''' + SAFETY


def run(*cmd: str, cwd: Optional[Path] = None) -> str:
    cp = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if cp.returncode:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}\n{cp.stderr[-2000:]}")
    return cp.stdout.strip()


def acquire(source: str, ref: str, tmp: Path) -> Path:
    input_path = Path(source).expanduser()
    if input_path.is_dir():
        return input_path.resolve()
    if source == UPSTREAM or source.rstrip('/') == UPSTREAM[:-4]:
        url = UPSTREAM
    else:
        raise ValueError('Only the official repository URL or a local source directory is allowed.')
    clone_dir = tmp / 'source'
    run('git', 'clone', '--depth', '1', '--no-tags', url, str(clone_dir))
    sha = run('git', 'rev-parse', 'HEAD', cwd=clone_dir)
    if ref != 'main':
        # The default pin is exact. Shallow clone is intentionally limited to HEAD;
        # this fails safely if upstream HEAD changes. --ref main opts into latest.
        if sha != ref:
            raise RuntimeError(f'Upstream revision changed: got {sha}, expected {ref}. Inspect upstream and pass --ref main to use the latest after review.')
    print(f'Upstream revision: {sha}')
    return clone_dir


def replace_provider_terms(text: str) -> str:
    fixes = {
      "Claude's own \"Allow once / Deny\" card": 'an explicit per-call approval prompt from the connected broker tool',
      "Claude's own Allow once / Deny card": 'an explicit per-call approval prompt from the connected broker tool',
      "Claude's own permission card": 'the connected broker tool\'s per-call approval prompt',
      "Claude Desktop config": 'local broker connector configuration',
      'Customize > Connectors > tool permissions': 'the broker tool permission settings in Codex',
      'Claude hands it to': 'Codex proceeds to',
      'Claude': 'Codex',
    }
    for a, b in fixes.items():
        text = text.replace(a,b)
    # Codex skills are normally invoked with $skill-name rather than Claude slash commands.
    names = '|'.join('trader-'+x for x in NAMES)
    text = re.sub(rf'(?<!\w)/({names})(?![\w/])', r'$\1', text)
    text = text.replace('${CLAUDE_SKILL_DIR}', '${CODEX_SKILL_DIR}')
    return text


def convert_skill(src: Path, dst: Path, name: str) -> None:
    if src.is_symlink():
        raise ValueError(f'Untrusted source is a symlink: {src}')
    if not (src / 'SKILL.md').is_file():
        raise ValueError(f'Missing SKILL.md in {src}')
    for f in src.rglob('*'):
        if f.is_symlink():
            raise ValueError(f'Untrusted symlink in source: {f}')
    shutil.copytree(src, dst)
    raw = (dst / 'SKILL.md').read_text('utf-8')
    mat = re.match(r'\A---\s*\n.*?\n---\s*\n', raw, flags=re.DOTALL)
    if mat is None:
        raise ValueError(f'SKILL.md has no frontmatter: {src}')
    body = raw[mat.end():]
    if name == 'broker':
        ref = dst / 'references'
        ref.mkdir(exist_ok=True)
        (ref / 'UPSTREAM_BROKER.md').write_text(raw, 'utf-8')
        body = BROKER_BODY
    else:
        body = replace_provider_terms(body)
        body = re.split(r'\n## Safety\s*\n', body)[0].rstrip() + '\n\n' + SAFETY
        intro = f'''\n> **Codex setup:** `CODEX_SKILL_DIR` is not defined automatically. Before running the shell snippets below, set it to the absolute directory that contains this `SKILL.md`. Codex should resolve that location from the selected skill path. For a normal personal install: `export CODEX_SKILL_DIR="${{CODEX_HOME:-$HOME/.codex}}/skills/trader-{name}"`. For a project install, use its `.agents/skills/trader-{name}` folder. Run commands from the trading project root so `trader/` state files stay in that project.\n'''
        body = intro + '\n' + body
    frontmatter = f'---\nname: trader-{name}\ndescription: {DESCRIPTIONS[name]}\n---\n\n'
    (dst / 'SKILL.md').write_text(frontmatter + body.lstrip(), 'utf-8')


def prepare_skills(source: Path, dest: Path, force: bool = False) -> None:
    """Stage and validate all 11 skills before changing the destination.

    Existing installs survive bad/missing input, including when --force is used.
    A failed final move attempts to restore the previous on-disk state.
    """
    # Check every upstream skill and every would-be destination first. This
    # avoids leaving a partial install if, say, the eleventh skill is missing.
    for name in NAMES:
        src = source / ('trader-' + name)
        if not src.is_dir() or src.is_symlink():
            raise ValueError(f'Missing or unsafe source skill: {src}')
        target = dest / ('trader-' + name)
        if (target.exists() or target.is_symlink()) and not force:
            raise FileExistsError(f'Refusing to overwrite: {target}')
        if target.is_symlink():
            raise ValueError(f'Refusing to replace symlink destination: {target}')

    dest.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.day-trader-codex-stage-', dir=dest) as temp:
        base = Path(temp)
        staged = base / 'staged'
        staged.mkdir()
        backup = base / 'backup'
        backup.mkdir()
        for name in NAMES:
            convert_skill(source / ('trader-' + name), staged / ('trader-' + name), name)
        if (source / 'LICENSE').is_file():
            if (source / 'LICENSE').is_symlink():
                raise ValueError('Refusing symlink upstream LICENSE')
            shutil.copy2(source / 'LICENSE', staged / 'UPSTREAM_LICENSE.txt')

        # A backup/rollback protects against failures in the last file move.
        changed = []
        old = []
        try:
            items = [('trader-' + name) for name in NAMES]
            if (staged / 'UPSTREAM_LICENSE.txt').exists():
                items.append('UPSTREAM_LICENSE.txt')
            for item in items:
                target = dest / item
                if target.exists():
                    if not force and item != 'UPSTREAM_LICENSE.txt':
                        raise FileExistsError(f'Refusing to overwrite: {target}')
                    target.rename(backup / item)
                    old.append(item)
                (staged / item).rename(target)
                changed.append(item)
        except Exception:
            for item in reversed(changed):
                target = dest / item
                if target.is_dir():
                    shutil.rmtree(target)
                elif target.exists():
                    target.unlink()
            for item in reversed(old):
                (backup / item).rename(dest / item)
            raise
    print(f'Converted {len(NAMES)} Codex skills into {dest}')


def plugin_manifest() -> dict:
    return {
      '$schema': 'https://agent-plugins.org/schemas/1.0.0/plugin.schema.json',
      'name': 'day-trader-codex',
      'version': '0.1.0',
      'description': 'Codex adaptation of Jake Schincariol\'s eleven MIT-licensed US stock day-trading skills. Analysis and paper trading by default; trading requires separate broker connection and per-order approvals.',
      'repository': 'https://github.com/Jakeschincariol/day-trader-skill',
      'license': 'MIT',
      'keywords': ['codex', 'day-trading', 'paper-trading', 'risk', 'backtesting'],
    }


def plugin_docs(path: Path) -> None:
    (path / 'plugin.json').write_text(json.dumps(plugin_manifest(), indent=2) + '\n', 'utf-8')
    (path / 'README.md').write_text('''# Day Trader for Codex\n\nCodex adaptation of Jake Schincariol's original MIT-licensed [day-trader-skill](https://github.com/Jakeschincariol/day-trader-skill). All eleven original Python tools are copied without changes. Instructions are adapted for Codex.\n\nContains `plugin.json` and `skills/trader-*/SKILL.md` in OpenAI's portable plugin layout. Add the plugin directory to a Codex personal marketplace, or copy the skill subfolders into `${CODEX_HOME:-$HOME/.codex}/skills/` for direct discovery.\n\n**No broker is configured by this package.** The ticket script is local bookkeeping, not a broker. Execution via an external MCP broker is paper-only in the Codex adapter and needs the exact order to pass the risk check, fresh confirmation from the user and separate approval for the tool call. If approval is unsupported, do not place an order. Never share keys in a chat.\n\n**Python:** 3.8+ according to upstream. No pip dependencies according to upstream. Free Yahoo/SEC data requires internet to run and is unofficial. The bundled time-machine simulations do not predict future results.\n\n**Working directory:** run scripts in a dedicated trading project. They read/write the relative `trader/` folder.\n\n**Original source:** https://github.com/Jakeschincariol/day-trader-skill, under the MIT license included as `skills/UPSTREAM_LICENSE.txt`. This adaptation is not endorsed by the upstream author.\n''', 'utf-8')


def write_global_notes(dest: Path, src: Path) -> None:
    (dest / 'README-CODEX-ADAPTER.txt').write_text('Codex adaptation of '+UPSTREAM+'\n'
      +'All 11 trader-* skills installed here. Restart Codex to refresh skills.\n'
      +'Python scripts unchanged. Brokerage actions require separate broker tools and approvals.\n', 'utf-8')


def main() -> int:
    parser = argparse.ArgumentParser(description='Adapt official day-trader-skill repository for Codex.')
    parser.add_argument('--mode', choices=['global','project','plugin'], default='global', help='Install to Codex personal skills (global), a project, or make a standalone plugin folder.')
    parser.add_argument('--source', default=UPSTREAM, help='Official repository URL or existing local clone.')
    parser.add_argument('--ref', default=PINNED_SHA, help='Expected exact commit for remote source, or main to explicitly accept the newest commit.')
    parser.add_argument('--project', default='.', help='Project root used with --mode project.')
    parser.add_argument('--out', help='Output directory used with --mode plugin.')
    parser.add_argument('--force', action='store_true', help='Replace an existing trader-* skill set in the chosen destination. Does not touch unrelated files.')
    parser.add_argument('--verify-upstream', action='store_true', help='Run upstream offline tests before converting (executes code from third-party repo).')
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='trader-codex-') as temporary:
        src = acquire(args.source, args.ref, Path(temporary))
        if args.verify_upstream:
            print('Running upstream offline unit tests (this executes cloned third-party Python code) ...')
            subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'],
                           cwd=src, timeout=180, check=True)
        if args.mode == 'global':
            dest = Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex'))).expanduser() / 'skills'
        elif args.mode == 'project':
            dest = Path(args.project).expanduser().resolve() / '.agents' / 'skills'
        else:
            if not args.out:
                parser.error('--out is required with --mode plugin')
            dest = Path(args.out).expanduser().resolve() / 'skills'
        if args.mode == 'plugin':
            root = dest.parent
            if root.exists() and any(root.iterdir()) and not args.force:
                raise FileExistsError(f'Output is not empty: {root} (use a fresh directory or --force)')
        prepare_skills(src, dest, force=args.force)
        if args.mode == 'plugin':
            plugin_docs(dest.parent)
            print(f'Portable Codex plugin created: {dest.parent}')
        else:
            write_global_notes(dest, src)
            print(f'Codex skills installed: {dest}')
        print('No broker connected; no order submitted.')
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (RuntimeError, FileNotFoundError, FileExistsError, ValueError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as err:
        print(f'ERROR: {err}', file=sys.stderr)
        raise SystemExit(1)

"""Safety and install-state integration tests for the Codex adapter.

These deliberately use a fake, harmless repository, so they never reach a
broker, fetch quotes, or execute upstream trading code.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parents[1]
CONVERTER = HERE / 'convert_day_trader.py'
NAMES = ['alerts', 'analyst', 'broker', 'budget', 'entry', 'exit', 'news', 'pelosi', 'risk', 'scanner', 'timemachine']


class IntegrityTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / 'src'
        self.source.mkdir()
        (self.source / 'LICENSE').write_text('MIT fixture\n')
        for n in NAMES:
            d = self.source / ('trader-' + n)
            d.mkdir()
            (d / 'SKILL.md').write_text(
                f'---\nname: trader-{n}\ndescription: local fixture\n---\n\n'
                'Use /trader-risk. Run `python3 "${CLAUDE_SKILL_DIR}/demo.py"`.\n\n'
                '## Safety\nClaude-only safety instructions to replace.\n'
            )
            (d / 'demo.py').write_text("print('safe smoke test')\n")

    def cli(self, *args, env=None):
        return subprocess.run([sys.executable, str(CONVERTER), '--source', str(self.source), *args],
                              capture_output=True, text=True, env={**os.environ, **(env or {})})

    def test_plugin_has_all_safeguards_and_scripts_untouched(self):
        target = self.root / 'plugin'
        cp = self.cli('--mode', 'plugin', '--out', str(target))
        self.assertEqual(cp.returncode, 0, cp.stderr)
        manifest = json.loads((target/'plugin.json').read_text())
        self.assertEqual(manifest['name'], 'day-trader-codex')
        self.assertTrue(manifest['$schema'].startswith('https://'))
        skills = list((target/'skills').glob('trader-*/SKILL.md'))
        self.assertEqual(len(skills), 11)
        for n in NAMES:
            d = target / 'skills' / ('trader-' + n)
            readme = (d / 'SKILL.md').read_text()
            self.assertIn(f'name: trader-{n}', readme)
            self.assertNotIn('${CLAUDE_SKILL_DIR}', readme)
            self.assertIn('paper', readme.lower())
            self.assertEqual((d/'demo.py').read_bytes(), (self.source/('trader-'+n)/'demo.py').read_bytes())
            if n != 'broker':
                self.assertIn('$trader-risk', readme)
                self.assertIn('CODEX_SKILL_DIR', readme)
            else:
                self.assertIn('per-call approval', readme)
                self.assertNotIn('Claude will call', readme)
        self.assertTrue((target/'skills/UPSTREAM_LICENSE.txt').is_file())

    def test_global_install_to_isolated_codex_home(self):
        home = self.root/'codex'
        cp = self.cli('--mode', 'global', env={'CODEX_HOME': str(home)})
        self.assertEqual(cp.returncode, 0, cp.stderr)
        self.assertEqual(len(list((home/'skills').glob('trader-*/SKILL.md'))), 11)
        self.assertTrue((home/'skills'/'README-CODEX-ADAPTER.txt').exists())
        # This is an actual command run from a generated installed skill path.
        r = subprocess.run([sys.executable, str(home/'skills/trader-scanner/demo.py')], capture_output=True, text=True)
        self.assertEqual((r.returncode, r.stdout.strip()), (0, 'safe smoke test'))

    def test_invalid_source_does_not_leave_partial_install(self):
        (self.source / 'trader-timemachine' / 'SKILL.md').unlink()
        home = self.root/'codex'
        cp = self.cli('--mode','global',env={'CODEX_HOME':str(home)})
        self.assertNotEqual(cp.returncode, 0)
        self.assertFalse(list((home/'skills').glob('trader-*/SKILL.md')))

    def test_force_failure_preserves_existing_skills(self):
        home = self.root/'codex'
        self.assertEqual(self.cli('--mode', 'global', env={'CODEX_HOME':str(home)}).returncode, 0)
        sentinel = home / 'skills/trader-scanner/keep.txt'
        sentinel.write_text('important existing customization')
        # Failed source means --force must never delete the existing install.
        (self.source/'trader-timemachine/SKILL.md').unlink()
        cp = self.cli('--mode','global','--force',env={'CODEX_HOME':str(home)})
        self.assertNotEqual(cp.returncode,0)
        self.assertEqual(sentinel.read_text(),'important existing customization')
        self.assertEqual(len(list((home/'skills').glob('trader-*/SKILL.md'))),11)

    def test_force_success_replaces_only_trading_skills(self):
        home = self.root/'codex'
        self.assertEqual(self.cli('--mode','global',env={'CODEX_HOME':str(home)}).returncode, 0)
        skills = home/'skills'
        (skills/'trader-scanner/keep.txt').write_text('old local custom change')
        (skills/'unrelated.txt').write_text('must survive')
        (self.source/'trader-scanner/demo.py').write_text("print('new')\n")
        cp=self.cli('--mode','global','--force',env={'CODEX_HOME':str(home)})
        self.assertEqual(cp.returncode, 0, cp.stderr)
        self.assertFalse((skills/'trader-scanner/keep.txt').exists())
        self.assertEqual((skills/'trader-scanner/demo.py').read_text(),"print('new')\n")
        self.assertEqual((skills/'unrelated.txt').read_text(),'must survive')

    def test_move_error_rolls_back_old_install(self):
        # Inject a filesystem error after some files have moved to exercise rollback.
        import importlib.util
        from unittest.mock import patch
        spec = importlib.util.spec_from_file_location('trader_adapter_testmodule', CONVERTER)
        adapter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(adapter)
        dest = self.root/'skills'
        adapter.prepare_skills(self.source, dest)
        sentinel = dest/'trader-scanner/keep.txt'
        sentinel.write_text('retained')
        real_rename = Path.rename
        def sabotaged_rename(path, target):
            if path.name == 'trader-entry' and path.parent.name == 'staged':
                raise OSError('simulated file system failure during skill move')
            return real_rename(path, target)
        with patch.object(Path, 'rename', sabotaged_rename):
            with self.assertRaises(OSError):
                adapter.prepare_skills(self.source, dest, force=True)
        self.assertEqual(sentinel.read_text(),'retained')
        self.assertEqual(len(list(dest.glob('trader-*/SKILL.md'))),11)
        self.assertFalse(list(dest.glob('.day-trader-codex-stage-*')))

    def test_symlink_source_rejected(self):
        p = self.source/'trader-scanner'/'danger.txt'
        try:
            p.symlink_to(self.source/'LICENSE')
        except OSError:
            self.skipTest('symlinks unavailable')
        cp = self.cli('--mode','project','--project',str(self.root))
        self.assertNotEqual(cp.returncode,0)
        self.assertIn('symlink',cp.stderr.lower())

    def test_no_overwrite_without_force(self):
        home=self.root/'codex'
        self.assertEqual(self.cli('--mode','global',env={'CODEX_HOME':str(home)}).returncode,0)
        sentinel=home/'skills/trader-scanner/keep.txt'
        sentinel.write_text('keep me')
        cp=self.cli('--mode','global',env={'CODEX_HOME':str(home)})
        self.assertNotEqual(cp.returncode,0)
        self.assertEqual(sentinel.read_text(),'keep me')

    def test_no_execution_on_install(self):
        # A script raises if run. Installation must copy it rather than execute it.
        target=self.source/'trader-entry/demo.py'
        target.write_text("raise RuntimeError('installer unexpectedly executed source script')\n")
        cp=self.cli('--mode','plugin','--out',str(self.root/'plugin'))
        self.assertEqual(cp.returncode,0,cp.stderr)

if __name__ == '__main__':
    unittest.main()

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
NAMES = ['alerts','analyst','broker','budget','entry','exit','news','pelosi','risk','scanner','timemachine']

class AdapterTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.src = self.base/'source'
        self.src.mkdir()
        (self.src/'LICENSE').write_text('MIT example license for fixture',encoding='utf8')
        for name in NAMES:
            d=self.src/('trader-'+name)
            d.mkdir()
            (d/'SKILL.md').write_text('---\nname: trader-'+name+'\ndescription: Original description\nargument-hint: foo\n---\n\n# Heading\n\nRun `python3 "${CLAUDE_SKILL_DIR}/demo.py"`. Then /trader-risk. Claude has a card.\n\n## Safety\nOriginal Claude-only instructions.\n', encoding='utf8')
            (d/'demo.py').write_text('print("hello")\n',encoding='utf8')
    def tearDown(self):
        self.tmp.cleanup()
    def call(self,*args):
        return subprocess.run([sys.executable, str(ROOT/'convert_day_trader.py'), '--source', str(self.src), *args], text=True, capture_output=True)
    def test_plugin_layout(self):
        dst=self.base/'out'
        r=self.call('--mode','plugin','--out',str(dst))
        self.assertEqual(r.returncode,0,r.stderr)
        meta=json.loads((dst/'plugin.json').read_text())
        self.assertEqual(meta['name'],'day-trader-codex')
        self.assertEqual(len(list((dst/'skills').glob('trader-*/SKILL.md'))),11)
        for name in NAMES:
            skill=(dst/'skills'/('trader-'+name)/'SKILL.md').read_text()
            self.assertIn('name: trader-'+name,skill)
            self.assertNotIn('CLAUDE_SKILL_DIR',skill)
            self.assertNotIn('Original Claude-only instructions',skill)
            self.assertIn('paper',skill.lower())
            self.assertEqual((dst/'skills'/('trader-'+name)/'demo.py').read_text(),'print("hello")\n')
        self.assertTrue((dst/'skills'/'trader-broker'/'references'/'UPSTREAM_BROKER.md').exists())
    def test_project_install_and_no_overwrite(self):
        r=self.call('--mode','project','--project',str(self.base))
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertTrue((self.base/'.agents/skills/trader-risk/SKILL.md').is_file())
        r2=self.call('--mode','project','--project',str(self.base))
        self.assertNotEqual(r2.returncode,0)
        r3=self.call('--mode','project','--project',str(self.base),'--force')
        self.assertEqual(r3.returncode,0,r3.stderr)

if __name__ == '__main__':
    unittest.main()
